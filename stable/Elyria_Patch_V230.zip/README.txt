V230 – Aufgeräumte Halle
- Die Liste „Deine Halle“ oben rechts wurde entfernt – sie überdeckte den Trophäenschrank
- Die Kampfimpuls-Anzeige erscheint nur noch in Expeditionen und verdeckt in der Halle nicht mehr die Bossrelikte

V229 – Das Siegel & Tagesprüfung
- Neu: Tagesprüfung (☼ unten rechts) – jeden Tag eine feste Tiefe, ein fester Schwur und eine von sechs Tagesregeln (Glasklingen, Schwarmtag, Elitentag, Unruhige Tiefe, Echoflut, Blutmond). Fünf Flügel bis zum Wächter, dann zählt die Tageswertung; Bestwerte der letzten Tage im Überblick; einmal pro Tag 150 Sonnenmark und Schmiedematerial
- Neu: Das Siegel (✕ unten rechts, sobald alle fünf Tiefen bezwungen sind) – der Kampf gegen Dagra, das Siebte im Lied. Dagra wechselt alle 13 Sekunden die Tiefe, mit deren Wächterangriff und Verstärkung; die Echos der Hüter sprechen dir Mut zu
- Erster Sieg über Dagra: exotische Waffe „Dagras Splitter“ und die achte Strophe; jeder weitere Sieg 300 Sonnenmark
- Drei neue Erfolge: Tagwerk, Sieben Tage, Das Siegel

V228 – Bestiarium & Erfolge
- Neu: Bestiarium (◈ unten rechts oder „Profil · Meine Chronik“) – jede Gegnerart der fünf Tiefen wird beim ersten Sieg erfasst und zählt mit. Ab 10 Siegen zeigt sie Fähigkeit und Konter, ab 50 Siegen +4 % und ab 150 Siegen +8 % Schaden gegen diese Art
- Neu: 23 Erfolge (★ unten rechts) in vier Gruppen – Tiefen, Kampf, Sammeln, Meisterschaft – mit Fortschrittsbalken und einmaliger Sonnenmark-Belohnung; bereits Erreichtes wird nachträglich gutgeschrieben
- Meldungen am rechten Rand für neue Bestiarium-Ränge und Erfolge
- Feinschliff: Funkenzünder und die anderen neuen Kreaturen erscheinen höchstens zweimal pro Welle
- Feinschliff: Echo-Texte laufen doppelt so schnell; Taste N blendet weiter
- Behebt: HUD-Leisten lagen über dem Talentfenster

V227 – Echos der Tiefe
- Story im Dungeon: Die Hüterinnen und Hüter aus Suris Lied (Neve, Halla, Corin, Belt, Marun, Ise) sprechen als Echos in ihren Tiefen – beim Betreten, in ruhigen Flügeln und vor jedem Wächter (mit Hinweis auf dessen Angriff). Kampf wird dabei nicht unterbrochen, Klick blendet weiter
- Nach jeder bezwungenen Expedition: Nachklang des Echos und eine neue Strophe von Suri; nach allen fünf Tiefen die siebte Strophe. Alles nachlesbar unter „Profil · Meine Chronik“
- Fünf neue Gegner, je einer pro Tiefe: Funkenzünder (zündet sich neben dir), Spreuling (zerfällt in zwei Hälften), Kristallweber (schildet Verbündete), Tintenspringer (springt hinter dich) und Leerenleger (legt Minen auf deinen Standort)
- Wächter erhalten unter 20 % Leben eine Verzweiflungsphase: schneller, stärker und mit Schockwellen, die man nur durch die Lücke oder per Rolle übersteht
- Neu: Tiefentalente (Taste T, dritter Reiter) – drei Zweige pro Waffenstil (Angriff, Bollwerk, Echo) mit je drei Talenten und einer Krone; Punkte für Wächter, Meisterprüfungen und alle 5 Stufen; Umverteilen im Dorf kostenlos
- Drei neue Echo-Fähigkeiten in der Runenschmiede: Echolanze, Sturmtotem und Bollwerksturm
- Grafik: schwebende Atmosphäre je Tiefe (Glut, Spreu, Steinstaub, Schriftzeichen, Leerenmotten), Abdrücke und Seelenfunken besiegter Gegner, Runensiegel unter Wächtern, Ringe unter Eliten, Staub bei Schritten und Rollen, Farbwechsel beim Flügelwechsel, Herzschlag bei wenig Leben
- Intern: 20 Spiel- und 14 Installer-Prüfungen vor jedem Release

V226 – Exotische Beute & automatische Updates
- Neu: Für den Endgegner gibt es keine Auswahl mehr, sondern genau ein exotisches Stück – neue Seltenheit „Exotisch“ (türkis), stärkere Werte und eine zusätzliche Endboss-Prägung
- Die exotische Beute lässt sich im Expeditionsabschluss direkt für den nächsten Lauf anlegen (bei Verbesserung bereits vorgewählt); keine Stufenanforderung; nicht fusionierbar
- Neu: Der Launcher holt Updates automatisch von GitHub (Abfrage beim Start, Einspielen nach Bestätigung, mit Prüfsumme und Rücksicherung)
- Bestehende Installationen erhalten beim Update die neue Update-Adresse; eigene Adressen bleiben erhalten

V225 – Sicherung & Chronik
- Neu: Menü-Reiter „Spielstand & Hilfe“ – alle Profile, Fortschritte und Einstellungen als Datei sichern und wiederherstellen (mit Vorschau); automatische Sicherungen alle 10 Minuten und nach jeder Expedition (letzte 3)
- Neu: „Fehler melden“ – erstellt einen Bericht mit Version, Ort im Spiel, Bildschirm und den letzten Fehlermeldungen (als Datei oder zum Kopieren), optional mit eigener Beschreibung
- Behebt: Echoscherben (Suris sieben Namen) wurden gemeldet, waren aber nirgends lesbar – jetzt als eingeklappte Lesezeile in der Runenschmiede und als Archiv unter „Profil · Meine Chronik“
- Leistung: Minikarte und Arenaboden werden zwischengespeichert – rund 60 % weniger Zeichenbefehle und 30–47 % weniger Rechenzeit pro Bild, Optik unverändert
- Intern: automatische Regressionstests (15 Spiel- und 13 Installer-Prüfungen) laufen vor jedem Release

V224 – Neuer Installer & Launcher
- Installer, Launcher und Deinstaller komplett neu aus eigenem Quellcode aufgebaut (kein Größenlimit mehr für das Spielpaket)
- Gleiche Pfade wie bisher: Installationen werden aktualisiert, Spielstände (Edge-Profil in %LOCALAPPDATA%\Elyria\DesktopRuntime) bleiben erhalten
- Installer erkennt vorhandene Installationen, zeigt den Fortschritt, sichert die alte Version und stellt sie bei Fehlern wieder her; Option „nach der Installation starten“
- Launcher mit Bildschirmwahl (gespeichert), Spielordner-Knopf und sicherem Update-System (HTTPS, SHA-256, Rollback)
- Deinstaller fragt, ob Spielstände ebenfalls gelöscht werden sollen (Standard: behalten)
- Windows-Manifest: läuft ohne Administratorrechte, scharf auf hochauflösenden Bildschirmen

V223 – Schmiedeaufträge
- Behebt: Gegenstände ließen sich nicht mehr aufwerten, weil es seit V220 keine Quelle für Aufwertungsmaterialien gab
- Neu: Brens Schmiedeaufträge im Reiter „Aufwerten“ – drei Aufträge gleichzeitig (Gegner besiegen, Flügel räumen, Elite-Gegner, Bosse, ganze Expeditionen); Belohnung: Sporenstaub, Wurzelsplitter, Aschestaub, Verderbniskristalle und Sonnenmark; nach dem Abholen folgt ein neuer Auftrag
- Materialbestand wird angezeigt; jede Aufwertung nennt, was noch fehlt
- Erfüllte Aufträge melden sich direkt im Kampf
- Fenstertitel springt nicht mehr auf alte Versionsnamen zurück

V222 – Klare Beute
- Behebt: Der Expeditionsabschluss zeigte eine Beuteauswahl an, bevor die Endgegner-Trophäe eingesetzt wurde – Spieler sahen andere Stücke, als tatsächlich in den Beutel kamen
- Neu: „Beute dieser Expedition“ steht jetzt ganz oben im Abschluss – große Karten mit Symbol, Art, Seltenheit, Werten und Vergleich zur angelegten Ausrüstung; klar getrennt, was in den Beutel wandert und was zu Sonnenmark zerlegt wird
- Beutel: größere Symbole, Art-Beschriftung (Klinge, Bogen, Stab, Schild, Rüstung, Anhänger, Talisman), Seltenheitsfarbe als Rahmen und Leuchten, lesbare Namen, NEU-Abzeichen für frische Beute, grünes ▲ wenn besser als angelegt, Farblegende
- Kampf-Hinweisfenster schimmern nicht mehr durch den geöffneten Beutel

V221 – Autoschuss
- Neu: Taste B schaltet den Autoschuss an/aus – die Figur zielt automatisch auf den nächsten Gegner in Reichweite und greift im Takt der Waffe an (Fernwaffen auf Distanz, Nahkampf erst in Schlagweite)
- Status und Umschalter in der Attributsleiste links (auch per Tippen); Taste im Steuerungsmenü frei belegbar; Einstellung wird gespeichert

V220 – Fusion, Schmiede & flüssige Wellen
- Neu: Ausrüstungsfusion im Beutel (Knopf „Fusion“): zwei Teile gleicher Art und Seltenheit ergeben ein Teil der nächsten Seltenheit mit verstärkten Bestwerten; angelegte Ausrüstung zählt mit, Schmiederänge bleiben erhalten
- Sera führt jetzt einen reinen Tränkeladen (Tränke und Tränkebündel, Ankauf nur von Tränken)
- Schmied Bren bietet fünf außergewöhnliche Meisterstücke (selten bis legendär, eines davon als Prunkstück); neue Auswahl nach jeder Expedition oder per „Neu schmieden“; Ankauf von Ausrüstung und Materialien
- Behebt Ruckler, wenn viele Monster gleichzeitig erscheinen: normale Gegner verzichten im Gedränge auf teure Weichzeichner-Schatten (im Test rund 4x schnellere Bilder bei 28 Gegnern)

V219 – Attribute & stärkere Gegner
- Gegner in Expeditionen: +30 % Leben und +20 % Angriffsschaden
- Bosse: +45 % Leben und +30 % Angriffsschaden
- Behebt: Das Expeditions-Panel oben links flackerte während Wellenereignissen (zwei Module bauten es abwechselnd neu auf)
- Neu: Attributsleiste links im Bild – Schaden, Kritisch, Krit-Schaden, Angriffe/s, Leben, Schutz, Lauftempo, Reichweite (und erlittener Schaden bei Risikorunen); per Klick auf „ATTRIBUTE“ einklappbar
- Neu: Runenschmiede zeigt „Deine Werte“ und auf jeder Karte die Änderung, z. B. Kritisch 4,2 % → 7,7 %
- Nach einer Wahl leuchten verbesserte Werte kurz grün auf

V218 – Klassenwahl-Fix
- Behebt: Bei der Klassenauswahl ging es nicht weiter – der Knopf „Mit … beginnen“ lag unsichtbar unterhalb des Bildschirms
- Klassenfenster passt sich jetzt jeder Auflösung an und kann bei Bedarf gescrollt werden; die Startknöpfe bleiben immer sichtbar
- Enter bestätigt die Auswahl, Pfeiltasten wechseln das Startset, Doppelklick auf eine Karte startet direkt

V217 – Installer-Hotfix
- Korrekte, unveränderliche Windows-GUIDs für Desktop-Verknüpfungen
- COM-freier Startdatei-Fallback auf beschädigten oder eingeschränkten Windows-Systemen
- Ein Verknüpfungsfehler kann die Spielinstallation nicht mehr zurückrollen

V216 – Reduzierter Launcher
- Nur noch eine sichtbare Aktion: Spiel starten
- Bildschirm, Auflösung und Leistung werden automatisch gewählt
- Updatekanal, Monitorwahl, Updateknopf und Spielordnerknopf aus der Oberfläche entfernt
- Update- und Reparatursicherheit bleiben intern erhalten

V215 – Interface-Neuaufbau
- Neues, ruhiges Hauptmenü mit den wesentlichen Aktionen
- Optionsmenü nur noch für Audio, Steuerung und HUD
- Anzeige und Auflösung werden automatisch an den Bildschirm angepasst
- Einheitliches Leistungsprofil ohne Grafik- oder Ultra-Einstellungen
- Kompakteres Kampf-HUD ohne doppelte Wellenanzeige und dauerhafte Tastenleiste

V214 – Taktikbilanz
Kumulatives Windows-Release mit vier neuen Erlebnis-Meilensteinen:
- V211 freiwillige Risikoziele für Wellenereignisse
- V212 Kampfimpuls aus trefferfreien Abschussserien
- V213 Gefahrenradar auf der vorhandenen Minikarte
- V214 taktische Ergänzung der Laufbilanz

V210 – Wellenereignisse
Vorhut, Zangenangriff und Elite-Nachhut eröffnen ausgewählte reguläre Wellen mit klarer Vorwarnung. Gegnerzahl, Beute und das einheitliche Leistungsprofil bleiben erhalten.

V209 – Gruppentaktik
Hotfix 209.0.1: Expeditionsbeitritt repariert und Gruppenberechnung großer Wellen beschleunigt.
Große Wellen verteilen sich auf bis zu 16 Positionen, greifen in drei wechselnden Trupps an und ziehen sich nach Schlägen kurz zurück. Das einheitliche Leistungsprofil bleibt aktiv.

V208 – Dichte Tiefenwellen
Jeder Abschnitt enthält deutlich mehr Gegner. Treiber, Bollwerke, Hetzer und Kriegssänger erzeugen gemischte Kampfgruppen; feste Obergrenzen schützen die Leistung. Das Grafikmenü bleibt bei einem einheitlichen, sicheren Leistungsprofil.

V207 – Zielberater für Belohnungen
Die Runenschmiede markiert Belohnungen, die zur gespeicherten Build-Vorlage passen, fehlende Bausteine erfüllen oder die Evolution unmittelbar auf 3/3 vervollständigen.

V206 – Build-Vorlagen
Vor einer Expedition lässt sich eine der sechs Evolutionen als Ziel speichern. Im Lauf zeigt eine Live-Checkliste, welche Endform, welches seltene Affix und welche Echo-Fähigkeit noch fehlen.

V205 – Build-Chronik
Abgeschlossene Läufe mit einer vollen Build-Evolution werden je Charakter gespeichert und über Bestpunkte, Bestzeit, tiefsten Flügel, bezwungene Tiefen und den direkten Vergleich zum letzten Lauf ausgewertet.

V204 – Evolutions-Meisterschaft
Jede der sechs Build-Evolutionen besitzt drei dauerhafte, charaktergebundene Meisterschaftsstufen. Flügel, ausgelöste Evolutionseffekte und passende Echo-Fähigkeiten schalten 18 rein kosmetische Titel frei.

V203 – Build-Evolutionen
Sechs Kampfstile entstehen aus passenden Waffenendformen, seltenen Affixen und Echo-Fähigkeiten. Zwei Bausteine aktivieren Resonanz, alle drei die volle Evolution mit eigenem Kampfeffekt.

V202 – Seltene Tiefenwächter
Fünf seltene Alternativwächter erscheinen in Bossabschnitten. Jeder besitzt drei Phasen, ein eigenes Gefahrenmuster und eine feste Gegenstrategie. Entdeckungen erscheinen dauerhaft in der Expeditionszentrale.

V201 – Monster-Gruppensynergien
Jede Tiefe besitzt einen eigenen Monsterverbund mit markiertem Anführer. Solange er lebt, erhält seine Gruppe mehr Schaden, Tempo, Schutz oder schnellere Fähigkeiten. Die Pfadwahl zeigt die passende Gegenstrategie.

V200 – Pfadspezifische Raumziele
Hüter-, Jagd- und Risspfad verändern nun das tatsächliche Kampfziel. Sechs Ziele wechseln sich ab: Ankerverteidigung, Schutzkreis, Tiefenjagd, Jagdzeichen, Risssiegel und Risssturm. Jede Tiefe besitzt einen eigenen Wächter.

V199 – Verzweigte Pfadketten
Nach jedem Abschnitt stehen drei klare Wege bereit: Hüterpfad, Jagdpfad und Risspfad. Wiederholte Entscheidungen bauen Ketten auf, verändern Gegnerdruck und Eliten und belohnen Mut mit vorhandener Wertung, Splittern und Beutestufen.

V198 – Einheitliche Performance-Grafik
Das Grafikmenü verwendet ein einziges abgestimmtes Profil. Es hält Beleuchtung und Lesbarkeit über alle Tiefen einheitlich, begrenzt die interne Renderauflösung auf 85 Prozent, setzt ein stabiles 60-FPS-Ziel und reduziert Partikel sowie Schatten. Helligkeit, Kontrast und Farbfilter bleiben frei einstellbar.

V197 – Erweiterte Welleneskalation
Die Expeditionen bauen ihren Kampfdruck nun in fünf klaren Stufen auf. Spätere Flügel bringen mehr Gegner, mehr gleichzeitig vertretene Monsterarten, zusätzliche Elitegegner und Nachhuten. Leben, Schaden und Tempo steigen kontrolliert. Zusatzgegner richten sich nach der Grafikstufe, damit schwächere Systeme geschützt bleiben.

V196 – Bosschronik und persönliche Rekorde
Jeder besiegte Expeditionswächter wird nun pro Tiefe erfasst. Die neue Chronik zeigt Bestzeit, geringsten erlittenen Schaden, knappsten Sieg, letzte Ergebnisse und erfolgreiche Bossaufträge. Die Daten werden pro Profil und Charakter gespeichert und verändern weder Kampfstärke noch Beute.

V195 – Optionale Bossaufträge
Jede Tiefe besitzt einen eigenen Bossauftrag mit einer klar sichtbaren Kampfbedingung. Aufträge lassen sich in der Expeditionszentrale markieren und werden in der nächsten passenden Wächterkammer verfolgt. Fehlschläge beenden den Lauf nicht und der Auftrag bleibt für den nächsten Versuch aktiv. Titel und Wächterzeichen sind rein kosmetisch.

V194 – Reliktmeisterschaften
Jedes der fünf Bossrelikte besitzt nun drei dauerhafte Meisteraufgaben: Relikt entdecken, seine einzigartige Wirkung im Kampf einsetzen und eine gezielte Reliktjagd abschließen. Die Belohnungen bleiben rein kosmetisch: gravierte Rahmen, eigene Titel und leuchtende Hallensiegel. Fortschritt wird pro Profil und Charakter gespeichert.

V193 – Gezielte Reliktjagden
Bereits entdeckte Bossrelikte lassen sich in der persönlichen Halle als Jagdziel markieren. Die Expeditionsauswahl und die ruhige Laufanzeige zeigen das Ziel. Beim erneuten Beanspruchen des passenden Bossrelikts kann eine von drei Prägungen gewählt oder das aktuelle Affix behalten werden. Jede Wahl zeigt Vorteil und Preis.

V192 – Reliktsammlung in der Halle
Ein eigener Schaukasten in der persönlichen Halle erfasst Bossrelikte dauerhaft pro Spielprofil und Charakter. Alle fünf Tiefen sind sichtbar; unbekannte Funde bleiben verdeckt. Entdeckte Relikte zeigen Boss, Wirkung, Anzahl der Funde und bekannte Affix-Varianten. Bereits besessene Relikte werden beim Laden nachgetragen.

V191 – Fünf Bossrelikte
Jede Tiefe besitzt ein benanntes Relikt mit eigener Wirkung. Das Relikt erscheint am ersten Boss-Kontrollpunkt, kann kostenlos beansprucht werden und bleibt Teil der vorhandenen Run-Ausrüstung. Bossrelikte können zusätzlich ein seltenes Affix tragen und lassen sich später wie andere Beute bergen.

V190 – Affix-Kampfanzeige
Aktive seltene Affixe stehen während des Kampfes in einer ruhigen Anzeige rechts unten. Letztes Bollwerk wechselt unter 40 Prozent Leben sichtbar von BEREIT auf AKTIV. Dorneneid und Seelensog melden Vergeltung beziehungsweise Heilung nur bei einem echten Auslöser. Die linke Kampfanzeige wird nicht verändert und unveränderte Zustände erzeugen keine neuen Oberflächenänderungen.

V189 – Affix-Schmiede
Zwischen zwei Flügeln kann ein ausgerüsteter Gegenstand sein Affix genau einmal neu prägen lassen. Die Schmiede verwendet vorhandene Runensplitter: seltene Funde kosten 10, epische 14 und legendäre 18 Splitter. Das neue Affix passt immer zur Gegenstandskategorie; Grundwerte und Gegenstand bleiben erhalten. Bereits neu geprägte Funde werden deutlich markiert und können nicht erneut gewürfelt werden.

V188 – Seltene Affixe
Seltene, epische und legendäre Beute kann nun eines von zehn benannten Affixen tragen. Jedes Affix verbindet eine spürbare Stärke mit einem festen Preis. Belohnungen, Händler, Ausrüstungsübersicht und Gegenstandstexte zeigen Vorteil und Nachteil vor der Entscheidung. Boss- und Meisterschaftsbeute erhält garantiert ein Affix. Bestehende Profile, laufende Expeditionen und V187-Waffenevolutionen bleiben kompatibel.

V187 – Legendäre Waffenevolutionen
Zwei gleiche Waffen auf Fusion II erschaffen nun auf Fusion III eine benannte Endform. Alle zehn Waffenprofile besitzen eine eigene Evolution mit eigener Wirkung und einem sichtbaren Preis: Morgenklinge, Weltenbrecher, Nachtzähne, Sturmlanze, Grünwindbogen, Belagerungseid, Zwillingsfluch, Sternenast, Glutherz und Chorprisma. Die Vorschau nennt das Ergebnis vor der Fusion; Karte und Gegenstandstext zeigen danach Vorteil und Nachteil. Bestehende Profile und laufende Expeditionen bleiben kompatibel.

V186 – Gift und Echos
Zwei neue Buildpfade erweitern jede Expedition: Der Seuchengärtner stapelt Gift, lässt vergiftete Gegner Giftblüten verbreiten und löst mit Seuchenstoß ein Zielgebiet aus. Der Echorufer beschwört bis zu drei sichtbare Kampfechos und kann ihnen mit Echoruf ein gemeinsames Ziel geben. Vier Runen, drei Synergien und zwei aktive Fähigkeiten sind vollständig in Belohnungen, Build-Kompass, HUD und Speicherstände eingebunden. Bosse begrenzen Gift auf fünf Stapel, erleiden weniger Giftschaden und unterbrechen Echos an Phasenwechseln; Beschwörer besitzen einen sichtbaren Echo-Bann. Das neue HUD bleibt auch bei schnellen Kampfaktualisierungen stabil.

V185 – Gegnerdruck und Bosskämpfe
Expeditionsmonster entdecken den Spieler 28 Prozent früher und alarmieren nahe Verbündete über eine größere Entfernung. Sie verfolgen den Spieler in der Arena konsequent, Fernkämpfer greifen häufiger an und bis zu vier Nahkämpfer können gleichzeitig Druck ausüben. Leben, Schaden und Tempo steigen kontrolliert mit Tiefe und Flügel. Bosse erhalten zusätzlich 40 bis 55 Prozent mehr Leben, 18 Prozent mehr Angriffsschaden, 30 Prozent schnellere Spezialmuster und beschleunigte eigene Fähigkeiten. Bodenexplosionen und Bossmuster verursachen im normalen Schwur nun spürbaren Schaden. Das Expeditions-HUD zeigt Gegner- oder Bossdruck und verwendet ein dauerhaftes, flackerfreies Anzeigeelement. V184-Kampflesbarkeit, Beute und Spielstände bleiben erhalten.V184 – Klarer Kampf
Die auf hohen und Ultra-Grafikstufen sichtbaren Sonnenstrahlen wurden aus den Expeditionsarenen entfernt, damit Gegner und Gefahrenflächen ruhig lesbar bleiben. Die Kohlearena und ihre Schienen bleiben erhalten. Blutung, Brand, Frost und Echo erhalten kleine, farbunabhängige Formzeichen über nahen Gegnern. Gefahrenflächen zeigen zusätzlich ein eindeutiges Warn- oder Aktivsymbol. Die Partikeldichte begrenzt Zusatzzeichen bei dichten Kämpfen. V183-Synergien, Kampfwerte, Beutetabellen und Speicherstände bleiben unverändert.
V183 – Synergie-Feedback
Neu aktivierte Build-Synergien werden während der Expedition mit Namen, Symbol und ihrer konkreten Wirkung deutlich angekündigt. Im Kampf-HUD stehen die aktiven Synergien sowie der nächste erreichbare Ausbau und die noch fehlenden Runenränge. Die Rückmeldung blockiert keine Eingaben und respektiert die Einstellung für reduzierte Bewegung. V182-Buildpfade, Kampfwerte und Beutetabellen bleiben unverändert.
V182 – Build-Kompass
Vor einer Expedition kann jetzt einer von fünf Buildpfaden gewählt werden: Sturmfront, Bastion, Schattenjagd, Echosturm oder Reaktionskern. Der Kompass zeigt passende Spielstile, den aktuellen Fortschritt und fünf leicht vergleichbare Werte. In der Runenschmiede werden passende Runen und Fähigkeiten hervorgehoben; wenn eine passive Rune angeboten werden kann, enthält die Auswahl mindestens eine passende Möglichkeit. Der gewählte Pfad bleibt im Kampf-HUD und in der Laufzusammenfassung sichtbar. Die Wahl wird getrennt je Chronik gespeichert. Vorhandene Kampfwerte und Beutetabellen bleiben unverändert.
V181 – Seltene Räume und Alternativwächter
Jede der fünf Tiefen besitzt jetzt einen seltenen Raum mit eigener Atmosphäre und einer klaren Entscheidung: Der mutige Weg gewährt sechs Runensplitter und aktiviert ein wiederkehrendes Gefahrenmuster; der sichere Weg heilt zwölf Prozent Leben. Auf den Wächterflügeln können fünf alternative Wächter erscheinen. Jeder bringt zwei klar angekündigte Kampfphasen und ein eigenes Bewegungsmuster mit. Entdeckte Räume und Wächter werden getrennt je Chronik gespeichert. Vorhandene Kampfwerte und Beutetabellen bleiben unverändert.
V180 – Aufträge und Trophäen
Drei wöchentliche Ziele führen durch vollständige Läufe, unterschiedliche Hauptwaffen und Meisterziele. Wer alle drei erfüllt, erhält ein dauerhaftes Wochenwappen für die Halle. Jede Tiefe besitzt außerdem ein kosmetisches Tiefenzeichen, das nach einem vollständigen Lauf und allen fünf entdeckten Begegnungen freigeschaltet wird. Der Trophäenschrank steht in der persönlichen Halle und wird getrennt je Chronik gespeichert. Alle Belohnungen sind rein kosmetisch und verändern weder Kampfwerte noch Beutechancen.
V179 – Dein Charakter
Vor dem ersten Abenteuer lässt sich ein bis zu 20 Zeichen langer Charaktername vergeben. Er wird getrennt vom Chroniknamen pro Profil gespeichert und erscheint im Kampf-HUD, in den Charakterwerten und in passenden Beutebeschreibungen. Unter Spielprofile kann der Name jederzeit geändert werden. Bestehende Profile starten sicher mit Wanderer, bis ein eigener Name gewählt wird.
V178 – Stabile Grafik
Die Grafikprofile wurden für stabile Laufzeit überarbeitet. Ultra rendert in nativer Schärfe statt 115 Prozent, verwendet automatisch 60 FPS, begrenzt Partikel auf 600 und schützt die Canvas-Fläche bei 4K und hohen Skalierungen mit einer Grenze von sechs Millionen Pixeln. Der alte absturzgefährdete Vollbildfilter wurde entfernt; Beleuchtung, Schatten, Tiefendetails, Figurenmerkmale und Partikel bleiben erhalten. Manuelle Bildraten reichen nun bis 120 FPS. Bestehende Einstellungen werden automatisch sicher übernommen.
V177 – Taktikpause
Die Pausenübersicht zeigt nun zusätzlich die aktuelle Kampflage: verbleibende Gegner, Elite- oder Bossgefahr, aktive Gegnerformation, aufladende Angriffe und offene Gegenfenster. Ein konkreter Gegenzug und ein eigener Mechanikhinweis für jede der fünf Tiefen helfen beim Wiedereinstieg. Die Angaben werden nur beim Öffnen der Pause aus dem laufenden Kampf gelesen. Die Ansicht ist bei 1366×768, 1920×1080 sowie 2560×1440 geprüft. Kampfwerte, Balance und Spielstände bleiben unverändert.
V176 – Pausenübersicht
Während einer aktiven Expedition zeigt die Spielseite des Pausenmenüs eine kompakte Laufübersicht. Sie nennt Tiefe, Spielart, Flügel, Laufzeit, aktuelles Ziel, Lebensstand, Build, Startwaffen, Runenränge, Splitter, Fundstücke und Kontrollpunkt. Die Karte erscheint nur im aktiven Lauf und verschwindet beim Fortsetzen. Die Ansicht ist bei 1366×768, 1920×1080 sowie 2560×1440 geprüft. Kampfwerte, Balance und Spielstände bleiben unverändert.
V175 – Klarer Neustart
Nach einem Tod beginnt derselbe Flügel wie bisher sofort neu. Eine ruhige, nicht blockierende Anzeige erklärt nun, dass Waffen, Runenränge, Splitter und ungeborgene Fundstücke erhalten bleiben, während Gegner, Gefahren, Flügelzeit und Meisterziel zurückgesetzt werden. Die Meldung verschwindet automatisch oder per Knopfdruck und ist bei 1366×768, 1920×1080 sowie 2560×1440 geprüft. Kampfwerte, Balance und Spielstände bleiben unverändert.
V174 – Startklar-Check
Der Expeditionsplan zeigt vor dem Start die Zahl und durchschnittliche Stärke der gewählten Waffen, ihre Rollenvielfalt sowie Gegnerleben und Gegnerschaden des aktuellen Schwurs. Pfad, Stahl und Riss erhalten klare Einstufungen; besonders riskante Kombinationen werden erklärt, bleiben aber startbar. Die Anzeige reagiert sofort auf Waffen- und Schwurwechsel und ist bei 1366×768, 1920×1080 sowie 2560×1440 geprüft. Kampfwerte, Balance und Spielstände bleiben unverändert.
V173 – Expeditionsplan
Die Expeditionszentrale empfiehlt aus dem vorhandenen Profilfortschritt einen konkreten nächsten Lauf. Offene Hauptpfade und Kontrollpunkte haben Vorrang, danach folgen die nächste freigeschaltete Meisterprüfung, fehlende Meisterziele, Kodexentdeckungen und persönliche Rekorde. Ein Knopf startet Tiefe und Spielart direkt mit dem aktuell gewählten Schwur; ein zweiter öffnet das passende Kodexziel. Die Ansicht ist bei 1366×768, 1920×1080 sowie 2560×1440 geprüft. Kampfwerte, Balance und Spielstände bleiben unverändert.
V172 – Schneller Wiedereinstieg
Nach einem gewerteten Lauf bietet die Laufbilanz drei direkte Wege weiterzuspielen: dieselbe Expedition mit identischer Tiefe, Spielart und Stahlschwur wiederholen, das empfohlene Ziel im Expeditionskodex ansehen oder zur Expeditionszentrale zurückkehren. Gewählte Beute wird bei jeder Aktion zuerst sicher geborgen. Die Aktionsleiste bleibt auch auf kleineren Bildschirmen erreichbar und ist bei 1366×768, 1920×1080 sowie 2560×1440 geprüft. Kampfwerte, Beute und Spielstände bleiben unverändert.
V171 – Klare Laufbilanz
Das Abschlussfenster fasst jeden gewerteten Lauf verständlich zusammen: stärkste Leistung, größter Verbesserungshebel und nächstes konkretes Expeditionsziel. Tempo, Meisterziele, Schaden, Tiefstleben, Neustarts, Zauber- und Waffennutzung sowie persönliche Rekorde stammen aus den bereits vorhandenen Messwerten. Das Fenster ist kompakter, scrollbar und bei 1366×768, 1920×1080 sowie 2560×1440 geprüft. Kampfwerte, Beute und Spielstände bleiben unverändert.
V170 – Klare Bergung
Kontrollpunkte zeigen Lebensstand, ungeborgene Fundstücke, Pakte und Laufpunkte. Weitergehen und Bergen erklären jeweils deutlich, was erhalten bleibt, was riskiert wird und was dauerhaft gesichert werden kann. Eine begründete Empfehlung reagiert auf Leben und Beutemenge; die Tasten 1 und 2 wählen direkt. Die Hilfe verändert weder Beute noch Kontrollpunkte, Kampfwerte oder Spielstände.
V169 – Klare Routen
Die Routenwahl zeigt Lebensstand, Splitter, Pakte, Build und Schwerpunkt. Jeder vorhandene Weg erhält eine kompakte Risiko- und Ertragseinstufung samt Begegnungsvorschau. Eine begründete Empfehlung reagiert auf die Reserven des laufenden Durchgangs; die Tasten 1 bis 3 wählen direkt. Kontrollpunkte und Paktauswahl bleiben getrennt. Die Hilfe verändert weder Routenerzeugung noch Kampfwerte oder Spielstände.
V168 – Klare Belohnungen
Die Runenschmiede zeigt den aktuellen Build und seinen Schwerpunkt direkt über den vier Angeboten. Eine begründete Empfehlung hebt die passendste Karte hervor; weitere Kennzeichnungen unterscheiden Synergien, Build-Fortsetzungen, Verbesserungen, neue Zauber und neue Richtungen. Alle Karten lassen sich direkt mit den Tasten 1 bis 4 wählen. Die Hilfe verändert weder den Belohnungspool noch Kampfwerte oder Spielstände.
V167 – Bosspräsentation
Bosskämpfe zeigen den Namen, die aktuelle Tiefe, Lebenspunkte und drei Phasen in einer zentralen, skalierenden Anzeige. Die bereits vorhandenen 15 Bossprofile liefern den Namen des aktiven Angriffsmusters und einen passenden Gegenhinweis. Vorstellungen, Phasenwechsel und der Sieg erhalten eigene kurze Einblendungen. Die allgemeine Ortsüberschrift weicht während des Bosskampfs, damit die Anzeigen sich nicht überlagern. Unveränderte Zustände werden nicht neu in die Oberfläche geschrieben; reduzierte Bewegung wird berücksichtigt.
V166 – Figuren und Kampflesbarkeit
Rollen erhalten erkennbare Ausrüstungs- und Silhouettenmerkmale. Elitegegner und Bosse werden durch ruhige Rahmen und eindeutige Rangzeichen hervorgehoben. Unterbrechungs-, Verwundbarkeits- und Gefahrenfenster besitzen klarere Ränder und Ablaufanzeigen. Spielerklassen erhalten dezente eigene Akzente. Niedrige Grafikqualität und reduzierte Bewegung bleiben berücksichtigt.
V165 – Grafische Tiefenidentität
Alle fünf Expeditionen besitzen jetzt eigene, sofort erkennbare Arenadetails: Schienen, Rohre und Glut im Kohlelager; Zahnwerke und Laufbänder in der Mühle; Bruchadern und Kristallsplitter im Steinrücken; Schrift, Seiten und Siegel im Archiv; Rissadern und Kernringe im Kernvorhof. Die Effekte skalieren mit der Grafikqualität und werden bei „Bewegung reduzieren“ statisch dargestellt.
V164.0.1 – Trainingsfenster nach Bereich
Das DPS- und Einführungsfenster erscheint nur innerhalb des markierten Übungsflügels. Beim Verlassen verschwindet es automatisch; beim Zurückkehren werden das laufende beziehungsweise letzte Messergebnis wieder angezeigt.
V164 – Tiefenidentität
Das Kohlelager besitzt bedienbare Druckventile, heiße Bahnen und Brens profilsichere Esse. Wellen verwenden sieben lesbare Kampfformationen; Sonderfähigkeiten, Eliteformationen und Bossangriffe öffnen Unterbrechungs- oder Verwundbarkeitsfenster. Die Mühlenkatakomben wechseln ihren Fördertakt. Gegnerrollen sind durch kleine Symbole erkennbar, das letzte Trainingsergebnis bleibt sichtbar, und alle neuen Laufzustände werden gespeichert. Reaktionsbelohnungen und Mühlenketten sind laufweit begrenzt.
V158 – Expeditionskodex
In der Expeditionszentrale öffnet ein neuer Kodex die Fortschrittsansicht aller fünf Tiefen. Er erfasst 25 wirklich erlebte Ereignisse, Eliteformationen und Bossmechaniken profilgetrennt, zeigt Hauptpfad, Prüfungen, Meisterziele und Beutemeilensteine sowie persönliche Lauf- und Bossrekorde und nennt das nächste sinnvolle Ziel.

V157 – Laufausgleich
Der erste Flügel jeder Tiefe beginnt ohne Elite. Frühe Gruppen und Herausforderungen bleiben übersichtlich, bezahlte Neuwahlen sind auf 12 Splitter begrenzt. Die neue lokale Laufbilanz zeigt Tempo, Schaden, Tiefstleben, Splitterfluss, Belohnungen und Bosszeiten.

V156 – Expeditionsvielfalt
Jede Tiefe besitzt zwei neue Raumereignisse mit sichtbarem Nutzen und Risiko, zwei benannte Eliteformationen und eine zusätzliche eigene Bossphase. Ereignisfolgen bleiben in gespeicherten Expeditionen erhalten.
V155 – Kampfgefühl
Treffer besitzen jetzt klaren Rückstoß und einen kurzen Einschlagbogen. Gegnerleben zeigt den gerade verlorenen Anteil kurz als hellen Rest. Ausweichrollen hinterlassen eine kräftigere Spur, besiegte Gegner einen ruhigen Abschlussring. Elite- und Bossangriffe werden mit Angriffsnamen, Countdown und Ausweichhinweis angekündigt. Reduzierte Bewegung dämpft alle neuen Bewegungsakzente.

V154 – Übungsflügel
Die eigene Halle besitzt jetzt einen Trainingsbereich mit Eisenholz-Puppe, DPS-Messung und einer kurzen Einführung in Bewegung, Ausweichen, Interaktion, Grundangriffe und Waffenfähigkeiten. Die Einführung kann übersprungen und jederzeit wiederholt werden.

V153 – Expeditionsklang
Das Titelthema läuft nur noch im Hauptmenü. Alle fünf Expeditionen besitzen eigene Musik, Klangtexturen und Akzente für Eintritt, Wellen, Eliten, Bosse und Siege.

V152.1 – Elyria-Programmsymbol
Das Titelsiegel kennzeichnet Launcher, Installation, Desktop- und Startmenü-Verknüpfung sowie Deinstallation.

V152 – Deine Chronik
Controller-Menüs, fünf Spielprofile, zwölf Build-Vorlagen mit Favoriten, Inventarsuche und Flügel-Autosave.
Im Titelmenü: Profil wählen. Im Spielmenü: Profile, Builds & Speichern.

V151.1 – Bildschirmkorrektur: vollständiges Spielbild im Launcherstart; skalierbares Launchermenü und vollständige Hintergrund-Neuzeichnung.

ELYRIA · DIE FÜNF TIEFEN — VERSION 151.0.0
================================================

START
  ElyriaLauncher.exe öffnen und „Spiel starten“ wählen. Der Launcher erkennt
  alle angeschlossenen Bildschirme und startet Elyria auf dem Bildschirm, auf
  dem er sich befindet. Alternativ kann ein Zielbildschirm gewählt werden.
  Das rahmenlose Desktop-Fenster übernimmt dessen vollständige Pixelauflösung.
  Eine Internetverbindung ist zum Spielen nicht erforderlich.

OPTIONEN
  Das gemeinsame Systemmenü ist im Titelbild oder im Spiel mit Esc erreichbar.
  Die automatische Hardwareempfehlung ist Standard. Anzeige, Renderauflösung,
  FPS, Grafikdetails, Audio, HUD und Tasten können manuell angepasst werden.
  V147 kann das automatische Profil für den verwendeten Bildschirm kalibrieren.
  Riskante Vollbild- oder Auflösungswechsel werden zwölf Sekunden getestet und
  bei fehlender Bestätigung oder einem Neustart automatisch zurückgesetzt.

SPIELSTAND
  Fortschritt wird in einem eigenen lokalen Elyria-Desktopprofil gespeichert.
  Updates verwenden stets denselben Pfad; Spielstände bleiben dadurch stabil.

UPDATES
  Der Launcher besitzt vollständige Patch-Unterstützung: HTTPS-Manifest,
  SHA-256-Prüfung, geschützte ZIP-Extraktion sowie atomaren Austausch mit
  Rückrollsicherung. In diesem Entwicklungsbuild ist noch kein öffentlicher
  Updateserver eingetragen. Später wird dessen HTTPS-Adresse einmalig in
  launcher-config.json hinterlegt.

DATEIEN
  game/index.html          Spiel
  ElyriaLauncher.exe       Launcher und Updateprogramm
  ElyriaUninstall.exe      Deinstallation
  version.json             installierte Version
  launcher-config.json     Updatekanal und Serveradresse

SYSTEM
  Windows 10/11, Desktop-Browser, empfohlen 1920×1080 oder 2560×1440.

HINWEIS
  Dieser unabhängige Entwicklungsbuild ist noch nicht digital signiert.
  Windows SmartScreen kann deshalb beim ersten Start nachfragen.


























